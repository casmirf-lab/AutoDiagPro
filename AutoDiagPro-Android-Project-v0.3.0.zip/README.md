# AutoDiag Pro 0.3.0 — VAG only

Android/Kotlin starter project focused on Volkswagen Group vehicles. It is **not yet a complete VAG diagnostic application** and is not represented as a working OBDeleven 3 replacement.

## Implemented in this build

- Android Bluetooth Classic SPP connection to paired ELM327-compatible adapters.
- Generic OBD-II Mode 03 DTC read and Mode 04 clear for that ELM327 connection.
- Bluetooth LE scan and GATT connection/discovery screen. It lists advertised BLE devices, connects to a selected device and reports public GATT service/characteristic UUIDs and properties. It does not read/write characteristics or send ECU commands.
- VAG data models and integration contracts for vehicle identity, control modules, DTCs, coding snapshots, adaptations, and an official SFD authorization provider boundary.
- Fail-closed SFD write policy contract. No SFD bypass, guessed tokens, undocumented protocol commands, or unknown characteristic writes are included.

## OBDeleven 3 status

The BLE discovery is only a transport reconnaissance step. It does **not** establish that AutoDiag Pro can speak the OBDeleven 3 diagnostic protocol. The public product documentation describes OBDeleven 3 as a Bluetooth diagnostic interface with VAG advanced diagnostics and coding, but does not publish a third-party BLE protocol/SDK in the public material reviewed for this project. OBDeleven also describes SFD authorization as a manufacturer-backed access process.

To complete a real OBDeleven 3 driver, we need one of:

1. An official OBDeleven developer SDK/API and written permission for third-party integration; or
2. A documented, licensed integration agreement and technical protocol specification from OBDeleven.

For SFD-protected writes, the app must use an authorized SFD provider/account flow. This project intentionally does not implement or bypass SFD authentication.

## Not yet implemented

- OBDeleven 3 diagnostic transport/protocol.
- Full VAG module scan over OBDeleven 3.
- VAG DTC read/clear through OBDeleven 3.
- UDS live data, long coding, adaptations, basic settings, output tests, or service functions through OBDeleven 3.
- Production SFD authorization provider.
- Real-vehicle validation.

The existing ELM327 DTC buttons are **not** a substitute for VAG all-module diagnostics and are not connected to the OBDeleven BLE session.

## Build

Codemagic workflow: `autodiag-pro-vag-debug`. The workflow extracts `AutoDiagPro-Android-Project-v0.3.0.zip`, generates a Gradle wrapper, and builds `app-debug.apk`.

## Safety

Never perform coding, adaptations, basic settings, output tests, or fault clearing while driving. Coding changes can disable safety-related vehicle functions. Back up original values and use only verified procedures for the exact ECU software/hardware version. SFD access must be authorized by the appropriate provider.
