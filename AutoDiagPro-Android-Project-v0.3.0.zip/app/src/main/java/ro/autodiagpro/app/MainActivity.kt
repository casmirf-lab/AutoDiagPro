package ro.autodiagpro.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.IOException
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executors

/**
 * AutoDiag Pro: standard OBD-II Mode 03/04 over classic Bluetooth ELM327 SPP.
 * This is NOT an OBDeleven 3 driver. No undocumented VAG coding/write services are exposed.
 */
class MainActivity : Activity() {
    private val worker = Executors.newSingleThreadExecutor()
    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var socket: BluetoothSocket? = null
    private var selectedDevice: BluetoothDevice? = null
    private var bleGatt: BluetoothGatt? = null
    private var bleScanCallback: ScanCallback? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private val bleSeen = linkedMapOf<String, BluetoothDevice>()
    private lateinit var bleDevicesBox: LinearLayout
    private lateinit var bleStatus: TextView
    private lateinit var status: TextView
    private lateinit var adapterText: TextView
    private lateinit var results: TextView
    private lateinit var devicesBox: LinearLayout
    private lateinit var readButton: Button
    private lateinit var clearButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        setStatus("Pregătit. Pentru citire DTC este necesar un adaptor ELM327 compatibil Bluetooth Classic (SPP).")
        showPairedDevices()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(28))
            setBackgroundColor(0xFF101820.toInt())
        }
        scroll.addView(root)
        setContentView(scroll)
        fun heading(text: String, size: Float, color: Int, top: Int = 0, bold: Boolean = false): TextView {
            return TextView(this).apply {
                this.text = text; textSize = size; setTextColor(color)
                if (bold) setTypeface(null, 1)
                if (top > 0) setPadding(0, dp(top), 0, dp(5))
                root.addView(this)
            }
        }
        heading("AUTODIAG PRO", 27f, 0xFFFFFFFF.toInt(), bold = true)
        heading("Diagnoză OBD-II • VAG first • fără abonament", 13f, 0xFF9FB3C8.toInt())
        heading("ADAPTOR BLUETOOTH", 13f, 0xFF58C4B8.toInt(), 22, true)
        status = heading("Inițializare…", 13f, 0xFFEAF2F8.toInt())
        adapterText = heading("Niciun adaptor selectat", 12f, 0xFFB7C7D6.toInt(), 8)
        devicesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(devicesBox)
        root.addView(actionButton("Reîncarcă dispozitivele asociate") { showPairedDevices() })
        heading("OBDELEVEN 3 – DETECTARE BLE", 13f, 0xFF58C4B8.toInt(), 24, true)
        bleStatus = heading("Căutarea BLE nu a fost pornită.", 12f, 0xFFD6E0E8.toInt())
        bleDevicesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(bleDevicesBox)
        root.addView(actionButton("Caută adaptoare BLE (12 secunde)") { startBleScan() })
        root.addView(actionButton("Deconectează sesiunea BLE") { closeBleGatt("Sesiune BLE închisă.") })
        heading("CODURI DE EROARE MOTOR (OBD-II)", 13f, 0xFF58C4B8.toInt(), 24, true)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        readButton = actionButton("Citește DTC") { readDtc() }
        clearButton = actionButton("Șterge DTC") { confirmClearDtc() }
        readButton.isEnabled = false
        clearButton.isEnabled = false
        actions.addView(readButton, LinearLayout.LayoutParams(0, dp(48), 1f))
        actions.addView(clearButton, LinearLayout.LayoutParams(0, dp(48), 1f).apply { leftMargin = dp(8) })
        root.addView(actions)
        results = heading("Nu există încă rezultate. Conectează un adaptor ELM327 compatibil.", 13f, 0xFFEAF2F8.toInt(), 10)
        heading("FUNCȚII VAG AVANSATE", 13f, 0xFF58C4B8.toInt(), 24, true)
        heading("Scanare module, codări Long Coding, Adaptations și Basic Settings: indisponibile în această versiune. Aceste operații necesită un driver VAG autorizat și protocol documentat. Nu sunt trimise comenzi de codare necunoscute.", 12f, 0xFFFFC857.toInt())
        heading("COMPATIBILITATE IMPORTANTĂ", 13f, 0xFF58C4B8.toInt(), 24, true)
        heading("Citirea/ștergerea DTC implementată aici folosește ELM327 prin Bluetooth Classic SPP. OBDeleven 3 nu este tratat ca ELM327: faptul că telefonul îl vede prin BLE nu oferă automat acces la protocolul său de diagnoză. Pentru OBDeleven 3, funcțiile avansate rămân blocate până la existența unei interfețe oficiale/documentate.", 12f, 0xFFD6E0E8.toInt())
        heading("SFD / CODARE VAG", 13f, 0xFF58C4B8.toInt(), 24, true)
        heading("Pregătit pentru integrarea unui furnizor autorizat SFD. Nu se transmit comenzi UDS, codări sau adaptări prin caracteristici BLE necunoscute. Detectarea GATT de mai jos este doar inventariere tehnică, nu confirmă compatibilitatea protocolului OBDeleven.", 12f, 0xFFFFC857.toInt())
        heading("Versiune 0.3.0 • VAG only • BLE discovery + OBD-II ELM327 separat", 11f, 0xFF8193A5.toInt(), 24)
    }

    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 12f; isAllCaps = false
        setOnClickListener { action() }
    }

    private fun hasBlePermissions(): Boolean {
        return if (Build.VERSION.SDK_INT >= 31) {
            checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        } else {
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun requestBlePermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT), 78)
        } else {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 78)
        }
    }

    private fun startBleScan() {
        if (!hasBlePermissions()) { requestBlePermissions(); return }
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null || !adapter.isEnabled) {
            bleStatus.text = "Activează Bluetooth înainte de scanare."
            return
        }
        val scanner = adapter.bluetoothLeScanner
        if (scanner == null) { bleStatus.text = "Scanner BLE indisponibil pe acest telefon."; return }
        try {
            bleScanCallback?.let { scanner.stopScan(it) }
            bleSeen.clear()
            bleDevicesBox.removeAllViews()
            bleStatus.text = "Se caută dispozitive BLE…"
            val callback = object : ScanCallback() {
                override fun onScanResult(callbackType: Int, result: ScanResult) {
                    val device = result.device
                    val key = device.address ?: return
                    if (!bleSeen.containsKey(key)) {
                        bleSeen[key] = device
                        val name = try { device.name ?: result.scanRecord?.deviceName ?: "Dispozitiv BLE fără nume" } catch (_: SecurityException) { "Dispozitiv BLE" }
                        runOnUiThread {
                            bleDevicesBox.addView(actionButton("$name\n$key • RSSI ${result.rssi} dBm") { connectBle(device, name) })
                            bleStatus.text = "Dispozitive BLE găsite: ${bleSeen.size}. Selectează adaptorul pentru inventariere GATT."
                        }
                    }
                }
                override fun onScanFailed(errorCode: Int) {
                    runOnUiThread { bleStatus.text = "Scanarea BLE a eșuat (cod $errorCode)." }
                }
            }
            bleScanCallback = callback
            scanner.startScan(callback)
            mainHandler.postDelayed({
                try { scanner.stopScan(callback) } catch (_: Exception) { }
                runOnUiThread {
                    if (bleSeen.isEmpty()) bleStatus.text = "Nu au fost găsite dispozitive BLE. Verifică alimentarea adaptorului și apropie telefonul."
                    else bleStatus.text = "Scanare încheiată: ${bleSeen.size} dispozitive."
                }
            }, 12_000)
        } catch (e: SecurityException) {
            bleStatus.text = "Permisiune BLE lipsă: ${e.message}"
        } catch (e: Exception) {
            bleStatus.text = "Eroare BLE: ${e.message}"
        }
    }

    private fun connectBle(device: BluetoothDevice, label: String) {
        if (!hasBlePermissions()) { requestBlePermissions(); return }
        closeBleGatt(null)
        bleStatus.text = "Conectare GATT la $label…"
        try {
            bleGatt = device.connectGatt(this, false, object : BluetoothGattCallback() {
                override fun onConnectionStateChange(gatt: BluetoothGatt, statusCode: Int, newState: Int) {
                    if (newState == BluetoothProfile.STATE_CONNECTED && statusCode == BluetoothGatt.GATT_SUCCESS) {
                        runOnUiThread { bleStatus.text = "Conectat BLE la $label. Se inventariază serviciile GATT…" }
                        gatt.discoverServices()
                    } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                        runOnUiThread { bleStatus.text = "Deconectat BLE (status $statusCode)." }
                        if (bleGatt === gatt) bleGatt = null
                        gatt.close()
                    }
                }
                override fun onServicesDiscovered(gatt: BluetoothGatt, statusCode: Int) {
                    val report = if (statusCode == BluetoothGatt.GATT_SUCCESS) {
                        gatt.services.joinToString("\n") { service ->
                            "Serviciu ${service.uuid}\n" + service.characteristics.joinToString("\n") { ch ->
                                "  Caracteristică ${ch.uuid} [properties=${ch.properties}]"
                            }
                        }.ifBlank { "Adaptorul nu a expus servicii GATT." }
                    } else "Inventarierea GATT a eșuat: status $statusCode"
                    runOnUiThread {
                        bleStatus.text = "Inventariere GATT pentru $label:\n$report\n\nAceste UUID-uri nu reprezintă, singure, protocolul de diagnoză. Nu s-au citit/scris caracteristici și nu s-au trimis comenzi ECU."
                    }
                }
            }, BluetoothDevice.TRANSPORT_LE)
        } catch (e: SecurityException) {
            bleStatus.text = "Permisiune BLE lipsă: ${e.message}"
        } catch (e: Exception) {
            bleStatus.text = "Conectarea GATT a eșuat: ${e.message}"
        }
    }

    private fun closeBleGatt(message: String?) {
        try { bleScanCallback?.let { BluetoothAdapter.getDefaultAdapter()?.bluetoothLeScanner?.stopScan(it) } } catch (_: Exception) { }
        bleScanCallback = null
        try { bleGatt?.disconnect(); bleGatt?.close() } catch (_: Exception) { }
        bleGatt = null
        if (message != null && ::bleStatus.isInitialized) bleStatus.text = message
    }

    private fun showPairedDevices() {
        if (!hasConnectPermission()) { requestConnectPermission(); return }
        val bt = BluetoothAdapter.getDefaultAdapter()
        if (bt == null) { setStatus("Telefonul nu are Bluetooth."); return }
        if (!bt.isEnabled) { setStatus("Activează Bluetooth și asociază adaptorul din setările Android."); return }
        try {
            val paired = bt.bondedDevices.orEmpty().sortedBy { it.name ?: it.address }
            devicesBox.removeAllViews()
            if (paired.isEmpty()) {
                devicesBox.addView(TextView(this).apply { text = "Nu există dispozitive asociate. Asociază adaptorul din Setări → Bluetooth."; setTextColor(0xFFEAF2F8.toInt()); textSize = 12f })
            } else {
                paired.forEach { device ->
                    val label = "${device.name ?: "Bluetooth OBD"}\n${device.address}"
                    devicesBox.addView(actionButton(label) { connect(device) })
                }
            }
            setStatus("${paired.size} dispozitive Bluetooth asociate. Selectează adaptorul ELM327.")
        } catch (e: SecurityException) { setStatus("Permisiune Bluetooth lipsă: ${e.message}") }
    }

    private fun connect(device: BluetoothDevice) {
        if (!hasConnectPermission()) { requestConnectPermission(); return }
        selectedDevice = device
        closeSocket()
        adapterText.text = "Selectat: ${device.name ?: "Bluetooth OBD"} (${device.address})"
        setStatus("Conectare la adaptor…")
        readButton.isEnabled = false; clearButton.isEnabled = false
        worker.execute {
            try {
                val s = device.createRfcommSocketToServiceRecord(sppUuid)
                s.connect()
                socket = s
                val init = listOf("ATZ", "ATE0", "ATL0", "ATS0", "ATH0", "ATSP0", "ATAT1", "0100")
                init.forEach { command -> exchange(s, command, 5000) }
                runOnUiThread {
                    setStatus("Conectat. Interfață ELM327 inițializată; protocolul OBD-II răspunde.")
                    readButton.isEnabled = true; clearButton.isEnabled = true
                }
            } catch (e: Exception) {
                closeSocket()
                runOnUiThread { setStatus("Conectarea/inițializarea a eșuat: ${e.message ?: "adaptor incompatibil"}. Verifică dacă este ELM327 SPP.") }
            }
        }
    }

    private fun readDtc() {
        val s = socket ?: run { setStatus("Conectează mai întâi un adaptor ELM327."); return }
        readButton.isEnabled = false; clearButton.isEnabled = false
        setStatus("Se citesc codurile de eroare…")
        worker.execute {
            try {
                val response = exchange(s, "03", 8000)
                val codes = decodeDtc(response, "43")
                runOnUiThread {
                    results.text = if (codes.isEmpty()) {
                        if (response.contains("NO DATA", true) || response.contains("UNABLE", true)) "ECU nu a returnat coduri: $response" else "Nu au fost raportate coduri DTC memorate. Răspuns: $response"
                    } else "Coduri DTC (${codes.size}):\n" + codes.joinToString("\n")
                    setStatus("Citire DTC terminată. Păstrează codurile înainte de ștergere.")
                    readButton.isEnabled = true; clearButton.isEnabled = true
                }
            } catch (e: Exception) { runOnUiThread { setStatus("Eroare la citirea DTC: ${e.message}"); readButton.isEnabled = true; clearButton.isEnabled = true } }
        }
    }

    private fun confirmClearDtc() {
        AlertDialog.Builder(this)
            .setTitle("Ștergi codurile DTC?")
            .setMessage("Salvează mai întâi codurile și repară cauza. Ștergerea poate reseta monitoarele de emisii și nu repară defecțiunea. Fă operația cu vehiculul staționat, contact pus și motor oprit.")
            .setNegativeButton("Anulează", null)
            .setPositiveButton("Șterge codurile") { _, _ -> clearDtc() }
            .show()
    }

    private fun clearDtc() {
        val s = socket ?: run { setStatus("Conectează mai întâi un adaptor ELM327."); return }
        readButton.isEnabled = false; clearButton.isEnabled = false
        setStatus("Se transmite comanda standard OBD-II de ștergere…")
        worker.execute {
            try {
                val response = exchange(s, "04", 8000)
                val ok = response.replace(" ", "").contains("44", ignoreCase = true)
                runOnUiThread {
                    results.text = if (ok) "ECU a confirmat comanda de ștergere (răspuns 44). Recitește codurile pentru verificare." else "ECU/adaptor nu a confirmat ștergerea. Răspuns: $response"
                    setStatus(if (ok) "Comandă de ștergere confirmată; verifică din nou DTC." else "Ștergerea nu a putut fi confirmată.")
                    readButton.isEnabled = true; clearButton.isEnabled = true
                }
            } catch (e: Exception) { runOnUiThread { setStatus("Eroare la ștergerea DTC: ${e.message}"); readButton.isEnabled = true; clearButton.isEnabled = true } }
        }
    }

    @Synchronized
    @Throws(IOException::class)
    private fun exchange(s: BluetoothSocket, command: String, timeoutMs: Int): String {
        val input = s.inputStream
        val output = s.outputStream
        while (input.available() > 0) input.read()
        output.write((command + "\r").toByteArray(Charsets.US_ASCII)); output.flush()
        val start = System.currentTimeMillis()
        val bytes = StringBuilder()
        while (System.currentTimeMillis() - start < timeoutMs) {
            if (input.available() > 0) {
                val ch = input.read()
                if (ch >= 0) {
                    val c = ch.toChar()
                    if (c == '>') break
                    bytes.append(c)
                }
            } else Thread.sleep(25)
        }
        if (bytes.isEmpty()) throw IOException("Timp expirat la comanda $command")
        return bytes.toString().replace("\r", " ").replace("\n", " ").trim()
    }

    private fun decodeDtc(raw: String, responsePrefix: String): List<String> {
        val cleaned = raw.uppercase(Locale.US).replace(Regex("[^0-9A-F]"), "")
        val start = cleaned.indexOf(responsePrefix)
        if (start < 0) return emptyList()
        val payload = cleaned.substring(start + responsePrefix.length)
        val out = mutableListOf<String>()
        var i = 0
        while (i + 4 <= payload.length) {
            val a = payload.substring(i, i + 2).toIntOrNull(16) ?: break
            val b = payload.substring(i + 2, i + 4).toIntOrNull(16) ?: break
            i += 4
            if (a == 0 && b == 0) continue
            val family = when ((a and 0xC0) shr 6) { 0 -> 'P'; 1 -> 'C'; 2 -> 'B'; else -> 'U' }
            val digit = (a and 0x30) shr 4
            out += String.format(Locale.US, "%c%X%X%X%X", family, digit, a and 0x0F, (b and 0xF0) shr 4, b and 0x0F)
        }
        return out.distinct()
    }

    private fun hasConnectPermission(): Boolean = Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
    private fun requestConnectPermission() { if (Build.VERSION.SDK_INT >= 31) requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 77) }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 77 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) showPairedDevices()
        else if (requestCode == 77) setStatus("Permisiunea Bluetooth Connect este necesară.")
        if (requestCode == 78 && grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) startBleScan()
        else if (requestCode == 78) bleStatus.text = "Permisiunile BLE sunt necesare pentru scanare/conectare."
    }

    private fun closeSocket() { try { socket?.close() } catch (_: Exception) { }; socket = null }
    private fun setStatus(message: String) { status.text = message }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() { closeSocket(); closeBleGatt(null); worker.shutdownNow(); super.onDestroy() }
}
