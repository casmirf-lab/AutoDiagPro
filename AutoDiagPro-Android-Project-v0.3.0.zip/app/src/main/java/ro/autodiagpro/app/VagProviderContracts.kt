package ro.autodiagpro.app

/**
 * Integration boundary for a future officially licensed VAG diagnostic provider.
 * This project deliberately contains no guessed OBDeleven BLE UUIDs, keys, tokens,
 * undocumented command framing, or SFD bypass logic.
 */

 data class VagVehicleIdentity(
    val vin: String?,
    val make: String?,
    val model: String?,
    val modelYear: Int?
)

data class VagControlModule(
    val address: String,
    val name: String,
    val partNumber: String? = null,
    val softwareVersion: String? = null,
    val codingSupported: Boolean = false,
    val adaptationsSupported: Boolean = false
)

data class VagFault(
    val code: String,
    val description: String?,
    val status: String?,
    val moduleAddress: String
)

data class CodingSnapshot(
    val moduleAddress: String,
    val coding: String,
    val capturedAtEpochMs: Long,
    val vehicleVin: String?
)

enum class SfdState { NOT_REQUIRED, LOCKED, AUTHORIZED, AUTHORIZATION_REQUIRED, UNSUPPORTED }

data class SfdAuthorization(
    val state: SfdState,
    val providerReference: String? = null,
    val expiresAtEpochMs: Long? = null
)

/** The implementation must be supplied by a provider authorized to issue/use VW SFD access. */
interface OfficialSfdAuthorizationProvider {
    suspend fun authorize(vin: String, controlModuleAddress: String): SfdAuthorization
}

/**
 * Adapter/diagnostic transport boundary. A production implementation must come from
 * documented, licensed OBDeleven integration material or another authorized interface.
 */
interface VagDiagnosticTransport {
    suspend fun connect(): Boolean
    suspend fun identifyVehicle(): VagVehicleIdentity
    suspend fun scanControlModules(): List<VagControlModule>
    suspend fun readFaults(moduleAddress: String): List<VagFault>
    suspend fun clearFaults(moduleAddress: String): Boolean
    suspend fun readCoding(moduleAddress: String): CodingSnapshot
    suspend fun writeCoding(snapshot: CodingSnapshot, authorization: SfdAuthorization?): Boolean
    suspend fun readAdaptation(moduleAddress: String, channel: String): String
    suspend fun writeAdaptation(moduleAddress: String, channel: String, value: String, authorization: SfdAuthorization?): Boolean
}

/**
 * Fail-closed policy: no coding/adaptation write may proceed unless SFD is not required
 * or a current official authorization is present. Transport still has to enforce this.
 */
object VagWritePolicy {
    fun mayWrite(sfdRequired: Boolean, authorization: SfdAuthorization?): Boolean {
        if (!sfdRequired) return true
        if (authorization?.state != SfdState.AUTHORIZED) return false
        val expiry = authorization.expiresAtEpochMs ?: return false
        return expiry > System.currentTimeMillis()
    }
}
