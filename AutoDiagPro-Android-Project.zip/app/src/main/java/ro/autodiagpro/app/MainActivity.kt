package ro.autodiagpro.app

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

/**
 * First-stage AutoDiag Pro transport shell.
 * It scans/connects to BLE peripherals and inventories GATT services only.
 * It intentionally does not send undocumented commands to OBDeleven hardware.
 */
class MainActivity : Activity() {
    private val mainHandler = Handler(Looper.getMainLooper())
    private lateinit var root: LinearLayout
    private lateinit var statusText: TextView
    private lateinit var devicesBox: LinearLayout
    private lateinit var servicesText: TextView
    private var scanner: BluetoothLeScanner? = null
    private var gatt: BluetoothGatt? = null
    private val found = linkedMapOf<String, BluetoothDevice>()
    private var scanning = false

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            val key = device.address ?: return
            if (!found.containsKey(key)) {
                found[key] = device
                runOnUiThread { addDeviceRow(device, result.rssi) }
            }
        }
        override fun onScanFailed(errorCode: Int) {
            runOnUiThread { setStatus("Scan Bluetooth eșuat (cod $errorCode). Verifică permisiunile și Bluetooth.") }
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            runOnUiThread {
                if (status == BluetoothGatt.GATT_SUCCESS && newState == BluetoothProfile.STATE_CONNECTED) {
                    setStatus("Conectat BLE. Se identifică serviciile dispozitivului…")
                    g.discoverServices()
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    servicesText.text = "Nu există o conexiune GATT activă."
                    setStatus("Deconectat (status $status).")
                    if (gatt === g) gatt = null
                    g.close()
                } else if (status != BluetoothGatt.GATT_SUCCESS) {
                    setStatus("Conexiune GATT nereușită (status $status).")
                }
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            runOnUiThread {
                if (status != BluetoothGatt.GATT_SUCCESS) {
                    setStatus("Conectat, dar citirea serviciilor GATT a eșuat (status $status).")
                    return@runOnUiThread
                }
                val lines = mutableListOf<String>()
                g.services.forEachIndexed { index, service ->
                    lines += "${index + 1}. Serviciu: ${service.uuid}"
                    service.characteristics.forEach { characteristic ->
                        val props = mutableListOf<String>()
                        val p = characteristic.properties
                        if (p and BluetoothGattCharacteristic.PROPERTY_READ != 0) props += "READ"
                        if (p and BluetoothGattCharacteristic.PROPERTY_WRITE != 0) props += "WRITE"
                        if (p and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0) props += "WRITE_NO_RESPONSE"
                        if (p and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0) props += "NOTIFY"
                        lines += "   • ${characteristic.uuid} [${props.joinToString(", ")}]"
                    }
                }
                servicesText.text = if (lines.isEmpty()) "Dispozitiv conectat, fără servicii GATT expuse." else lines.joinToString("\n")
                setStatus("Conectat BLE. ${g.services.size} servicii GATT detectate. Protocolul auto nu este încă validat.")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        val manager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
        val adapter = manager.adapter
        if (adapter == null) setStatus("Telefonul nu oferă Bluetooth.")
        else if (!adapter.isEnabled) setStatus("Activează Bluetooth pentru a căuta adaptorul.")
        else setStatus("Pregătit. Caută adaptorul OBDeleven 3.")
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(28))
            setBackgroundColor(0xFF101820.toInt())
        }
        scroll.addView(root)
        setContentView(scroll)

        addText("AUTODIAG PRO", 27f, 0xFFFFFFFF.toInt(), true)
        addText("Diagnoză auto • VAG first • Android", 14f, 0xFF9FB3C8.toInt())
        addText("CONEXIUNE ADAPTOR", 13f, 0xFF58C4B8.toInt(), true, 20)
        statusText = addText("Inițializare Bluetooth…", 14f, 0xFFEAF2F8.toInt())
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        actions.addView(makeButton("Caută OBDeleven 3") { startBleScan() }, LinearLayout.LayoutParams(0, dp(50), 1f))
        actions.addView(makeButton("Deconectează") { disconnect() }, LinearLayout.LayoutParams(0, dp(50), 1f).apply { leftMargin = dp(8) })
        root.addView(actions)
        devicesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(devicesBox)
        addText("MODULE DE DIAGNOZĂ", 13f, 0xFF58C4B8.toInt(), true, 24)
        addFeature("VAG – scanare module", "Audi • Volkswagen • SEAT • Škoda", "Driver OBDeleven nevalidat")
        addFeature("Coduri de eroare (DTC)", "Citire, descriere și ștergere controlată", "Transport ECU indisponibil")
        addFeature("Date live", "RPM • temperaturi • presiuni • tensiuni", "Transport ECU indisponibil")
        addFeature("Codări și adaptări VAG", "Long coding • adaptations • Basic Settings", "Necesită protocol VAG și autorizare")
        addFeature("Alte mărci", "BMW • Mercedes • Toyota • Renault • Ford etc.", "Module OEM în dezvoltare")
        addText("SERVICII BLUETOOTH GATT", 13f, 0xFF58C4B8.toInt(), true, 24)
        servicesText = addText("Conectează adaptorul pentru a vedea serviciile expuse.", 12f, 0xFFB7C7D6.toInt())
        addText("NOTĂ TEHNICĂ", 13f, 0xFFFFC857.toInt(), true, 24)
        addText("Această versiune verifică descoperirea BLE, conexiunea GATT și inventariază serviciile. Nu trimite comenzi de scriere/codare către ECU. OBDeleven 3 folosește un protocol proprietar; funcțiile VAG avansate nu pot fi declarate funcționale până când transportul și comenzile sunt documentate și testate pe hardware real.", 12f, 0xFFD6E0E8.toInt())
        addText("Versiune 0.1.0 • fără cont, abonament, reclame sau credite", 11f, 0xFF8193A5.toInt(), false, 24)
    }

    private fun addFeature(title: String, subtitle: String, state: String) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(13), dp(11), dp(13), dp(11))
            setBackgroundColor(0xFF1C2A36.toInt())
        }
        val lp = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(7) }
        root.addView(card, lp)
        card.addView(TextView(this).apply { text = title; textSize = 16f; setTextColor(0xFFFFFFFF.toInt()); setTypeface(null, 1) })
        card.addView(TextView(this).apply { text = subtitle; textSize = 12f; setTextColor(0xFFB7C7D6.toInt()) })
        card.addView(TextView(this).apply { text = state; textSize = 11f; setTextColor(0xFFFFC857.toInt()); setPadding(0, dp(5), 0, 0) })
    }

    private fun addText(value: String, size: Float, color: Int, bold: Boolean = false, top: Int = 0): TextView {
        val view = TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, 1)
            if (top > 0) setPadding(0, dp(top), 0, dp(4))
        }
        root.addView(view)
        return view
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 12f; isAllCaps = false
        setOnClickListener { action() }
    }

    private fun startBleScan() {
        if (!hasBluetoothPermissions()) {
            requestBluetoothPermissions()
            return
        }
        val adapter = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (adapter == null || !adapter.isEnabled) {
            setStatus("Activează Bluetooth în setările telefonului.")
            return
        }
        scanner = adapter.bluetoothLeScanner
        if (scanner == null) { setStatus("Scanarea BLE nu este disponibilă pe acest telefon."); return }
        found.clear(); devicesBox.removeAllViews()
        try {
            scanner?.startScan(scanCallback)
            scanning = true
            setStatus("Scanare BLE în curs timp de 15 secunde…")
            mainHandler.postDelayed({ stopBleScan() }, 15_000)
        } catch (e: SecurityException) { setStatus("Permisiune Bluetooth lipsă: ${e.message}") }
    }

    private fun stopBleScan() {
        if (!scanning) return
        try { scanner?.stopScan(scanCallback) } catch (_: Exception) { }
        scanning = false
        if (found.isEmpty()) setStatus("Nu a fost găsit niciun dispozitiv BLE. Verifică alimentarea adaptorului și încearcă din nou.")
        else setStatus("Scanare terminată. ${found.size} dispozitive BLE găsite.")
    }

    private fun addDeviceRow(device: BluetoothDevice, rssi: Int) {
        val name = try { device.name ?: "Dispozitiv BLE fără nume" } catch (_: SecurityException) { "Dispozitiv BLE" }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(2)) }
        val info = TextView(this).apply { text = "$name\n${device.address} • $rssi dBm"; textSize = 12f; setTextColor(0xFFEAF2F8.toInt()) }
        row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(makeButton("Conectează") { connect(device) })
        devicesBox.addView(row)
    }

    private fun connect(device: BluetoothDevice) {
        if (!hasBluetoothPermissions()) { requestBluetoothPermissions(); return }
        stopBleScan()
        disconnect()
        setStatus("Se conectează la adaptor…")
        try { gatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE) }
        catch (e: SecurityException) { setStatus("Conexiune refuzată: ${e.message}") }
    }

    private fun disconnect() {
        try { gatt?.disconnect(); gatt?.close() } catch (_: Exception) { }
        gatt = null
        servicesText.text = "Conectează adaptorul pentru a vedea serviciile expuse."
        setStatus("Adaptor deconectat.")
    }

    private fun hasBluetoothPermissions(): Boolean {
        if (Build.VERSION.SDK_INT < 31) return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestBluetoothPermissions() {
        val permissions = if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT) else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        requestPermissions(permissions, 42)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 42 && grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) startBleScan()
        else if (requestCode == 42) setStatus("Permisiunile Bluetooth sunt necesare pentru conectare.")
    }

    override fun onDestroy() {
        stopBleScan()
        try { gatt?.close() } catch (_: Exception) { }
        gatt = null
        super.onDestroy()
    }

    private fun setStatus(message: String) { statusText.text = message }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
