# AutoDiag Pro — Android starter 0.1.0

Native Kotlin Android application, VAG-first architecture, with a BLE discovery and GATT connection/inventory screen.

## Current implementation
- Android BLE permission handling (Android 6–15 compatible permission paths).
- BLE scan, device list, GATT connection, service/characteristic UUID inventory.
- No account, subscriptions, ads, credits, or backend dependency.
- VAG-first feature roadmap displayed in the app.
- Java and Kotlin JVM targets both pinned to 17.

## Critical hardware limitation
OBDeleven 3 is not an ordinary ELM327 adapter. The manufacturer advertises it as a Bluetooth device with licensed, multi-brand and VAG-specific functionality. This starter app deliberately limits itself to BLE discovery, GATT connection, and service inventory. It does **not** claim that it can yet exchange diagnostic commands with OBDeleven 3, scan control modules, read/clear DTCs, or perform VAG coding. The device protocol, authentication/handshake, transport framing, and supported command set must be independently documented or obtained from an authorized SDK and then validated on the actual dongle. No undocumented writes are sent to the vehicle.

## Build
- JDK 17
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- compileSdk 35, minSdk 23
- `gradle wrapper --gradle-version 8.9`
- `./gradlew assembleDebug`

## Next engineering milestones
1. Capture and document OBDeleven 3 BLE advertisement/GATT profile from a real device.
2. Confirm whether the device exposes a supported third-party SDK/API and licensing terms.
3. Implement authenticated transport only against documented interfaces.
4. Add read-only generic OBD-II PIDs and DTC workflows where supported.
5. Add VAG UDS/KWP diagnostic sessions, ECU discovery, measuring values, coding/adaptation only after protocol, security access, and vehicle-specific safety rules are validated.
6. Add adapters for other OEMs as independent modules; do not promise universal full-system access.

## Safety
Never run coding, adaptations, actuator tests, or resets while driving. Keep a stable battery supply for service operations. The current build is a BLE connectivity prototype, not a certified diagnostic tool.
